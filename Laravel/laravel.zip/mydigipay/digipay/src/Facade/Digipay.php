<?php

namespace MyDigipay\Digipay\Facade;

use Illuminate\Support\Facades\Facade;
use MyDigipay\Digipay\DigipayGateway;

/**
 * Class KamvaCrud
 * @package Kamva\Crud
 * @method static DigipayGateway    init()
 * @method static bool              verify()

 */
class Digipay extends Facade
{

    /**
     * The name of the binding in the IoC container.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'digipay';
    }
}
