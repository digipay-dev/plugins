<?php
/**d
 * @package    Digipay payment Gateway
 * @author     DigiPay
 * @copyright  2021  mydigipay.com
 * @version    1.0
 */
if (!defined('_PS_VERSION_'))
	exit ;

class DigiPayGW extends PaymentModule {

	public function __construct() {

		$this->name 			= 'digiPayGW';
		$this->tab 				= 'payments_gateways';
		$this->version 			= '1.0';
		$this->author 			= 'DigiPay';
		$this->currencies 		= true;
		$this->currencies_mode 	= 'radio';
        $this->bootstrap        = true;
		parent::__construct();

		$this->displayName 		= $this->l('درگاه پرداخت هوشمند دیجی پی');
		$this->description 		= $this->l('پرداخت آنلاین تمامی سفارشات با دیجی پی');

		if (!sizeof(Currency::checkPaymentCurrencies($this->id))){
			$this->warning = $this->l('No currency has been set for this module');
		}

		$config = Configuration::getMultiple(array('digiPayGW_username'));

		if (!isset($config['digiPayGW_username'])){
			$this->warning = $this->l('لطفا ابتدا اطلاعات ماژول دیجی پی را تکمیل کنید');
		}
	}

	public function install() {
		return (
			parent::install()                                           &&
			$this->registerHook('payment')                              &&
			$this->registerHook('paymentReturn')                        &&
			Configuration::updateValue('digiPayGW_type', 		    '') &&
			Configuration::updateValue('digiPayGW_username', 		'') &&
			Configuration::updateValue('digiPayGW_password', 		'') &&
			Configuration::updateValue('digiPayGW_client_id', 		'') &&
			Configuration::updateValue('digiPayGW_client_secret', 	'') &&
			Configuration::updateValue('digiPayGW_refresh_token', 	'') &&
			Configuration::updateValue('digiPayGW_access_token', 	'')
		);
	}

	public function uninstall() {
		return (
			Configuration::deleteByName('digiPayGW_type') 		&&
			Configuration::deleteByName('digiPayGW_username') 		&&
			Configuration::deleteByName('digiPayGW_password') 		&&
			Configuration::deleteByName('digiPayGW_client_id') 	    &&
			Configuration::deleteByName('digiPayGW_client_secret')  &&
			Configuration::deleteByName('digiPayGW_refresh_token')  &&
			Configuration::deleteByName('digiPayGW_access_token')   &&

			parent::uninstall());
	}

	public function getContent() {

		if (Tools::isSubmit('digiPayGW_setting')) {

			Configuration::updateValue('digiPayGW_type', 		    $_POST['digiPayGW_type']);
			Configuration::updateValue('digiPayGW_username', 		$_POST['digiPayGW_username']);
			Configuration::updateValue('digiPayGW_password', 		$_POST['digiPayGW_password']);
			Configuration::updateValue('digiPayGW_client_id', 		$_POST['digiPayGW_client_id']);
			Configuration::updateValue('digiPayGW_client_secret', 	$_POST['digiPayGW_client_secret']);
			Configuration::updateValue('digiPayGW_refresh_token', 	null);
			Configuration::updateValue('digiPayGW_access_token', 	null);

			$this->_html .= '<div class="conf confirm">' . $this->l('Settings updated') . '</div>';
		}


		return $this->form();
	}

    private function _input($title, $name, $value = null, $options = [],$hint = '')
    {
        $_options = '';
        foreach ($options as $key => $option){
            $_options .= '<option '.(($value == $key) ? 'selected' : '').' value="'.$key.'">'.$option.'</option>';
        }

        return '<div class="form-group"><label class="control-label col-lg-3 required"><span class="label-tooltip" data-toggle="tooltip" title="">'. $title .'</span></label><div class="col-lg-8">'
                . (empty($options) ? '<input type="text" name="'. $name .'" value="'. $value .'">' : '<select name="'. $name .'">'. $_options .'</select>')
                . "<small>". $hint ."</small>"
                . '</div></div>';
	}

	private function form() {

	    $out  ='<div><form id="module_form" class="defaultForm form-horizontal" action="' . $_SERVER['REQUEST_URI'] . '" method="post" enctype="multipart/form-data" novalidate=""> <input type="hidden" name="btnSubmit" value="1"> <div class="panel" id="fieldset_0"> <div class="panel-heading"> تنظیمات درگاه پرداخت هوشمند دیجی پی </div> <div class="form-wrapper">';
        $out .= $this->_input('نوع درگاه',              'digiPayGW_type',           Configuration::get('digiPayGW_type'),[
            'IPG'     => 'درگاه پرداخت هوشمند (IPG)',
            'UPG'     => 'درگاه پرداخت جامع (UPG)',
            'WPG'     => 'درگاه کیف پولی (WPG)',
        ],'IPG - درگاه پرداخت هوشمند دیجی پی که با استفاده از الگوریتم های مختلف بهترین درگاه را در لحظه برای مشتری شما انتخاب می کند <Br><Br>WPG - درگاه پرداخت کیف پولی دیجی پی که امکان پرداخت از طریق کیف پول دیجی پی را برای مشتریان شما فراهم می کند <Br><Br>UPG - درگاه پرداخت جامع دیجی پی که ترکیبی از درگاه هوشمند و کیف پول را در خود دارد،  اگر کیف پول کسب و کاری شما راه اندازی شده پیشنهاد ما استفاده از این روش پرداخت است.');
        $out .= $this->_input('نام کاربری (username)',  'digiPayGW_username',       Configuration::get('digiPayGW_username'));
        $out .= $this->_input('رمزعبور (password)',     'digiPayGW_password',       Configuration::get('digiPayGW_password'));
        $out .= $this->_input('Client ID',              'digiPayGW_client_id',      Configuration::get('digiPayGW_client_id'));
        $out .= $this->_input('Client Secret',          'digiPayGW_client_secret',  Configuration::get('digiPayGW_client_secret'));

        $out .= '</div><!-- /.form-wrapper --> <div class="panel-footer"> <button type="submit" value="1" id="module_form_submit_btn" name="digiPayGW_setting" class="btn btn-default pull-right"> <i class="process-icon-save"></i> ذخیره </button> </div> </div> </form></div> ';

        return $out;
	}

    function convertToIRR($amount, $currency)
    {
        switch ($currency){
            case 'IRR'  :
                return $amount;

            case 'IRT'  :
                return $amount * 10;

            default :
                throw new Exception("این ارز در دیجی پی پشتیبانی نمیشود");

        }
    }

	public function error($str) {
		return '<div class="alert error">' . $str . '</div>';
	}

	public function success($str) {
		echo '<div class="conf confirm">' . $str . '</div>';
	}

	public function hookPayment($params) {
		global $smarty;
		$smarty ->assign('zarinpalwg_logo', Configuration::get('zarinpalwg_LOGO'));
		if ($this->active)
			return $this->display(__FILE__, 'dp_payment.tpl');
	}

    public function hookPaymentReturn($params) {
        if ($this->active)
            return $this->display(__FILE__, 'zpconfirmation.tpl');
    }
}
