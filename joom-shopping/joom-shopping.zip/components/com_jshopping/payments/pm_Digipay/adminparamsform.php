<?php
/**
 * @package     Joomla - > Site and Administrator payment info
 * @subpackage  com_Jshopping
 * @subpackage 	mydigipay_Digipay
 * @copyright   MyDigipay => https://mydigipay.com
 * @copyright   Copyright (C) 20016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die();
?>
<div class="col100">
<fieldset class="adminform">
<table class="admintable" width = "100%" >
    <tr>
        <td  class="key">
            Type
        </td>
        <td style="text-align: right;">
            <select  name = "pm_params[type]" >
                <option value="IPG" <?php if($params['type'] == 'IPG'){ ?> selected <?php } ?>>درگاه پرداخت هوشمند (IPG)</option>
                <option value="UPG" <?php if($params['type'] == 'UPG'){ ?> selected <?php } ?>>درگاه پرداخت جامع (UPG)</option>
                <option value="WPG" <?php if($params['type'] == 'WPG'){ ?> selected <?php } ?>>درگاه کیف پولی (WPG)</option>
            </select>
            <?php echo JHTML::tooltip('IPG - درگاه پرداخت هوشمند دیجی پی که با استفاده از الگوریتم های مختلف بهترین درگاه را در لحظه برای مشتری شما انتخاب می کند <Br><Br>WPG - درگاه پرداخت کیف پولی دیجی پی که امکان پرداخت از طریق کیف پول دیجی پی را برای مشتریان شما فراهم می کند <Br><Br>UPG - درگاه پرداخت جامع دیجی پی که ترکیبی از درگاه هوشمند و کیف پول را در خود دارد،  اگر کیف پول کسب و کاری شما راه اندازی شده پیشنهاد ما استفاده از این روش پرداخت است.');?>
        </td>
        <input type="hidden" name="pm_params[access_token]"  value="" />
        <input type="hidden" name="pm_params[refresh_token]" value="" />
    </tr>
    <tr>
        <td  class="key">
            Username
        </td>
        <td style="text-align: right;">
            <input type = "text" class = "inputbox" name = "pm_params[username]" size="100" value = "<?php echo $params['username']?>" />
            <?php echo JHTML::tooltip('نام کاربری (username)');?>
        </td>
    </tr>
    <tr>
        <td  class="key">
            Password
        </td>
        <td style="text-align: right;">
            <input type = "text" class = "inputbox" name = "pm_params[password]" size="100" value = "<?php echo $params['password']?>" />
            <?php echo JHTML::tooltip('رمزعبور (password)');?>
        </td>
    </tr>
    <tr>
        <td  class="key">
            Client ID
        </td>
        <td style="text-align: right;">
            <input type = "text" class = "inputbox" name = "pm_params[client_id]" size="100" value = "<?php echo $params['client_id']?>" />
            <?php echo JHTML::tooltip('ClientID');?>
        </td>
    </tr>

    <tr>
        <td  class="key">
            Client Secret
        </td>
        <td style="text-align: right;">
            <input type = "text" class = "inputbox" name = "pm_params[client_secret]" size="100" value = "<?php echo $params['client_secret']?>" />
            <?php echo JHTML::tooltip('Client Secret');?>
        </td>
    </tr>

    <tr>
        <td class="key">
            <?php echo _JSHOP_TRANSACTION_END;?>
        </td>
        <td style="text-align: right;">
            <?php
            print JHTML::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[transaction_end_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_end_status'] );
            ?>
        </td>
    </tr>
    <tr>
        <td class="key">
            <?php echo _JSHOP_TRANSACTION_PENDING;?>
        </td>
        <td style="text-align: right;">
            <?php
            echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_pending_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_pending_status']);
            ?>
        </td>
    </tr>
    <tr>
        <td class="key">
            <?php echo _JSHOP_TRANSACTION_FAILED;?>
        </td>
        <td style="text-align: right;">
            <?php
            echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[transaction_failed_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['transaction_failed_status']);
            ?>
        </td>
    </tr>
</table>
</fieldset>
</div>
<div class="clr"></div>
