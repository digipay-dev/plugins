<?php

/**
 * @package    digiPayGW
 * @author     DigiPay
 * @copyright  2021  mydigipay.com
 * @version    1.00
 */

error_reporting(E_ALL);

ini_set('display_errors',           1);
ini_set('display_startup_errors',   1);

$do         = !empty($_GET['do']) ? $_GET['do'] : null;

if ($do) {

    include         dirname(__FILE__) . '/../../config/config.inc.php';
    include         dirname(__FILE__) . '/../../header.php';
    include_once    dirname(__FILE__) . '/DigiPayGW.php';
    include_once    dirname(__FILE__) . '/DPGateway.php';


    $settings = [
        'type'              => Configuration::get('digiPayGW_type'),
        'username'          => Configuration::get('digiPayGW_username'),
        'password'          => Configuration::get('digiPayGW_password'),
        'client_id'         => Configuration::get('digiPayGW_client_id'),
        'client_secret'     => Configuration::get('digiPayGW_client_secret'),
        'access_token'      => Configuration::get('digiPayGW_access_token'),
        'refresh_token'     => Configuration::get('digiPayGW_refresh_token'),
    ];

    $updaterHook = function ($accessToken, $refreshToken){
        Configuration::updateValue('digiPayGW_access_token',    $accessToken);
        Configuration::updateValue('digiPayGW_refresh_token',   $refreshToken);

        return true;
    };

    $dp         = new DPGateway($settings, $updaterHook);
    $digipayGw  = new DigiPayGW();
    $orderId    = $_GET['id'];

    switch ($do){
        case 'pay'      :
            try {
                $amount         = $digipayGw->convertToIRR(round($cart->getOrderTotal(true)), $currency->iso_code);
                $orderId        = $cart->id;
                $callbackUrl    = (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . __PS_BASE_URI__ . 'modules/digiPayGW/dp.php?do=callback&id=' . $cart ->id;

                $url = $dp->createTicket($amount, $orderId, $callbackUrl);

                $cookie->{'dp_order_'. $orderId} = md5($orderId . $amount . Configuration::get('digiPayGW_client_secret'));
                Tools::redirect($url);

            }catch (Exception $e){
                echo _err($e->getMessage());
            }

        break;
        case 'callback' :
            $orderId        = $cart->id;

            if(!empty($_POST['result']) && $_POST['result'] == 'SUCCESS'){

                $result         = $_POST['result'];
                $amount         = $_POST['amount'];
                $providerId     = $_POST['providerId'];
                $trackingCode   = $_POST['trackingCode'];

                if (md5($orderId . $amount . Configuration::get('digiPayGW_client_secret')) != $cookie->{'dp_order_'. $orderId}) {
                    echo _err('خطا در تایید تراکش');
                    return;
                }

                $cookie->{'dp_order_'. $orderId} = null;
                try{
                    $dp->verifyTicket($trackingCode);
                    echo 'Transaction successful. TrackingCode:' . $trackingCode;
                    $digipayGw->validateOrder($orderId, _PS_OS_PAYMENT_, $cart->getOrderTotal(true), $digipayGw->displayName, "سفارش تایید شده / کد رهگیری {$trackingCode}", [], $cookie->id_currency);

                    return Tools::redirect('history.php');

                }catch (Exception $e){
                    echo _err($e->getMessage());
                    return;
                }

            }else{

                echo _err('خطا در پرداخت با دیجی پی');
                return;
            }

        break;
        default:
            abort();
    }

    include_once (dirname(__FILE__) . '/../../footer.php');
} else {
    abort();
}

function abort() {
    header('Status: 403 Forbidden');
    header('HTTP/1.1 403 Forbidden');

    exit();
}
function _err($str) {
    return '<div class="alert alert-warning">' . $str . '</div>';
}
function _success($str) {
    echo '<div class="alert alert-success">' . $str . '</div>';
}

