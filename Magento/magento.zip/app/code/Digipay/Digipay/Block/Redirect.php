<?php
namespace Digipay\Digipay\Block;

use Exception;
use Magento\Backend\Model\View\Result\RedirectFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\View\Element\Template;
use Magento\Sales\Model\Order;
use Digipay\Digipay\Model\LogFactory;
use Digipay\Digipay\DPGateway;
/**
 * Class Redirect
 * @package Digipay\Digipay\Block
 *  =>t id
 * =>username
 * =>password
 */
class Redirect extends \Magento\Framework\View\Element\Template
{

    protected $_checkoutSession;
    protected $_orderFactory;
    protected $_scopeConfig;
    protected $_scopeConfigWriter;
    protected $_urlBuilder;
    protected $messageManager;
    protected $redirectFactory;
    protected $catalogSession;
    protected $digipay_log;
    protected $customer_session;

    /**
     * @var $order Order
     */
    protected $order;
    protected $response;

  private $namespace='http://interfaces.core.sw.bps.com/';
    public function __construct(\Magento\Checkout\Model\Session $checkoutSession, \Magento\Sales\Model\OrderFactory $orderFactory, \Magento\Framework\Message\ManagerInterface $messageManager, LogFactory $digipay_log, Session $customer_session, RedirectFactory $redirectFactory, \Magento\Framework\App\Response\Http $response, Template\Context $context, array $data, \Magento\Framework\App\Config\Storage\WriterInterface $configWriter){
        $this->customer_session     = $customer_session;
        $this->digipay_log          = $digipay_log;
        $this->_checkoutSession     = $checkoutSession;
        $this->_orderFactory        = $orderFactory;
        $this->_scopeConfig         = $context->getScopeConfig();
        $this->_scopeConfigWriter   = $configWriter;
        $this->_urlBuilder          = $context->getUrlBuilder();
        $this->messageManager       = $messageManager;
        $this->redirectFactory      = $redirectFactory;
        $this->response             = $response;

        parent::__construct($context, $data);

    }

    public function initDP()
    {
        $config = [
            'type'            => $this->getConfig('type'),
            'username'        => $this->getConfig('username'),
            'password'        => $this->getConfig('password'),
            'client_id'       => $this->getConfig('client_id'),
            'client_secret'   => $this->getConfig('client_secret'),
            'access_token'    => $this->getConfig('access_token'),
            'refresh_token'   => $this->getConfig('refresh_token')
        ];

        $updater = function ($accessToken, $refreshToken){
            $this->setConfig('access_token',  $accessToken);
            $this->setConfig('refresh_token', $refreshToken);
        };

        return new DPGateway($config, $updater);

    }

    public function sendToBank()
    {

        if (!$this->getOrderId()) {
            $this->response->setRedirect($this->_urlBuilder->getUrl(''));
            return "";
        }

        $response['state']  = true;
        $response['msg']    = "";

        try{
            $dp             = $this->initDP();
            $mobile         = null;
            $userAddress    = $this->customer_session->getCustomer()->getAddresses();
            if(!empty($userAddress)){
                $mobile     = $userAddress[0]->getTelephone();
            }
            $url = $dp->createTicket($this->getOrderPrice(), $this->getOrderId(), $this->getCallBackUrl(), $mobile);

            $response['state']      = true;
            $response['msg']        = $url;

        }catch (Exception $e){
            $response['msg']        = "DP_ERR:" . $e->getMessage();
            $response['state']      = false;
        }

        //create log
        if($response['state']){
            $msg    = "customer send to bank";
            $this->changeStatus($this->getBeforeOrderStatus());
        }else{
            $this->changeStatus(Order::STATE_CANCELED);
            $msg    = $response['msg'];
        }
        $log_data   = [
            'state'             => 0,
            'customer_id'       => $this->customer_session->getCustomer()->getId(),
            'order_id'          => $this->getOrderId(),
            'time_create'       => time(),
            'amount'            => $this->getOrderPrice(),
            'message'           => $msg
        ];

        $this->saveLog($log_data);
        return $response;
    }

    public function saveLog(array $data){
        $this->digipay_log->create()->addData($data)->save();
    }

    public function updateLog(array $data){


        $log=$this->digipay_log->create()->getCollection()
            ->addFieldToFilter("order_id",$data['order_id'])
            ->addFieldToFilter("state",0)
        ->getFirstItem();
        if(!$log->getData())
            return;
        $updated_log=$this->digipay_log->create()->load($log->getId());
            $updated_log->setData($data)
                ->setId($log->getId())
            ->save();
    }

    public function getFormData($paramter)
    {
        return $this->getConfig($paramter);
    }

    public function getOrderPrice(){


        $extra = 10;
        if($this->useToman()){
            $extra=1;
        }

        /** @var \Magento\Sales\Model\Order $order */
        $order      = $this->getOrder();
        $amount     =$order->getGrandTotal();

        if($this->useToman()){
            $amount *= 10;
        }

        return  (int) $amount;
    }

    private function getOrder(){

       return $this->_orderFactory->create()->load($this->getOrderId());
    }

    function changeStatus($status){
        $order  = $this->getOrder();
        $order->setStatus($status);
        $order->save();
    }

    public function getOrderId(){

        return isset($_COOKIE['order_id']) ? $_COOKIE['order_id'] : false;
    }

    public function getCallBackUrl(){
        return $this->_urlBuilder->getUrl('checkout/onepage/success');
    }

    public function countPrice($order_item){
        $price = 0;
        foreach ($order_item as $_item) {
                $price += $_item->getPrice();
        }
        return $price;
    }

    private function getConfig($value){
        return $this->_scopeConfig->getValue('payment/digipay/'.$value, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    private function setConfig($key, $value){
        return $this->_scopeConfigWriter->save('payment/digipay/'.$key ,$value, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getBeforeOrderStatus()
    {
        return $this->getConfig('order_status');
    }

    public function getAfterOrderStatus()
    {
        return $this->getConfig('after_order_status');
    }

    public function useToman()
    {
        return $this->getConfig('isirt');
    }

    public function verifySettleTransaction(){

        $data           = $this->getRequest()->getParams();
        $order          = $this->getOrder();
        $customer_id    = $this->customer_session->getCustomerId();

        $result         = $data['result'];
        $amount         = $data['amount'];
        $providerId     = $data['providerId'];
        $trackingCode   = $data['trackingCode'];

        $response['state']  = false;
        $response['msg']    = "";

        if(!$order->getData()){

            $response['msg']    = "این تراکنش قبلا اعتبار سنجی شده است.";

        }else {



                if ($result === 'SUCCESS') {


                    try{
                        $dp             = $this->initDP();
                        $dp->verifyTicket($trackingCode);

                        $response['state'] = true;
                        $response['msg'] = __('تراکنش با موفقیت ثبت شد . شماره تراکنش : %1', $trackingCode);


                    }catch (Exception $e){
                        $response['state']      = false;
                        $response['msg']        = $e->getMessage();
                    }

                }else{
                    $response['state']      = false;
                    $response['msg']        = 'تراکنش لغو شد';
                }

            if ($response['state']) {
                $this->changeStatus($this->getAfterOrderStatus());
            } else {
                $this->changeStatus(Order::STATE_CANCELED);
            }


            $log_data = [
                'state'         => $response['state'],
                'customer_id'   => $customer_id,
                'order_id'      => $this->getOrderId(),
                'amount'        => $this->getOrderPrice(),
                'message'       => $response['msg']
            ];
            $this->updateLog($log_data);
            $this->removeOrderId();
        }

        return $response;
    }

    function removeOrderId()
    {
        setcookie("order_id", "", time() - 3600,"/");
    }
}

