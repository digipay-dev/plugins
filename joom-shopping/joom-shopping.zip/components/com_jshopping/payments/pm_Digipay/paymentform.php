<?php
/**
 * @package     Joomla - > Site and Administrator payment info
 * @subpackage  com_Jshopping
 * @subpackage 	mydigipay_Digipay
 * @copyright   MyDigipay => https://mydigipay.com
 * @copyright   Copyright (C) 20016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
function pm_Digipay(){
    jQuery('#payment_form').submit();
}
</script>
