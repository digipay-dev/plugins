<?php
$_['heading_title']       = 'پرداخت هوشمند دیجی پی';
$_['text_wait']           = 'لطفا صبر کنید';
$_['text_extension']   	  = 'افزونه ها';
$_['text_success']        = 'ماژول پرداخت زرين پال با موفقیت ویرایش شد!';
$_['text_digipay']  	  = '<a href="http://www.digipay.com" target="_blank"><img src="view/image/payment/digipay.png" alt="زرين پال" title="زرين پال" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_edit']           = 'ویرایش پرداخت آنلاین زرين پال';
$_['entry_order_status']  = 'وضعیت سفارش';
$_['entry_status']        = 'وضعیت';
$_['entry_sort_order']    = 'ترتیب';

// Error
$_['error_permission']    = 'هشدار شما اجازه ویرایش ماژول زرين پال را ندارید!';
