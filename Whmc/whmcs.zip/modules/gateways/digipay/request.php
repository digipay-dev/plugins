<?php

require_once(__DIR__ . '/../../../init.php');
require_once(__DIR__ . '/../../../includes/gatewayfunctions.php');
require_once(__DIR__ . '/../../../includes/invoicefunctions.php');
require_once(__DIR__ . '/DPGateway.php');

$gatewayParams = getGatewayVariables('digipay');

if ($gatewayParams['type'] == false) {
    die('Module Not Activated');
}

$paymentAmount  = isset($_POST['amount'])       ? $_POST['amount']      : null;
$callbackUrl    = isset($_POST['callback'])     ? $_POST['callback']    : null;
$invoiceId      = isset($_POST['invoice_id'])   ? $_POST['invoice_id']  : null;
$mobile         = isset($_POST['mobile'])       ? $_POST['mobile']      : null;

$dp             = new DPGateway([
    'username'          => $gatewayParams['username'],
    'password'          => $gatewayParams['password'],
    'client_id'         => $gatewayParams['client_id'],
    'client_secret'     => $gatewayParams['client_secret'],
    'type'              => $gatewayParams['type'],

], function ($accessToken, $refreshToken){});


try {

    if(substr($mobile,0,1) != "0"){
        $mobile = "0" . $mobile;
    }

    $ticket     = $dp->createTicket($paymentAmount, $invoiceId, $callbackUrl, $mobile, false);
    $_SESSION['p_'.$invoiceId] = $ticket['ticket'];

    header('Location: ' . $ticket['url']);
    exit;

}catch (Exception $e){

    logTransaction($gatewayParams['name'], [
        'Code'      => 'Send',
        'Message'   => $e->getMessage(),
        'Invoice'   => $invoiceId
    ] , 'Failure');

    $invoiceId ? header('Location: '.$gatewayParams['systemurl'].'viewinvoice.php?id='.$invoiceId . '&err=' . $e->getMessage()) : header('Location: '.$gatewayParams['systemurl'].'clientarea.php?action=invoices'. '&err=' . $e->getMessage());
    exit;
}
