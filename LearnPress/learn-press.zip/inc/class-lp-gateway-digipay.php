<?php

defined( 'ABSPATH' ) || exit;

if(!class_exists('DPGateway')){
    include_once "DPGateway.php";
}

if (!class_exists( 'LP_Gateway_Digipay' )){

	class LP_Gateway_Digipay extends LP_Gateway_Abstract {

        protected $form_data    = [];
		protected $order        = null;
		protected $posted       = null;

		public function __construct() {
			$this->id                   = 'digipay';
			$this->method_title         =  'Digipay';
			$this->method_description   = 'Digipay payment gateway for learnpress';
			$this->icon                 = LP_ADDON_DIGIPAY_PAYMENT_URL . 'assets/images/digipay.png';
			$this->title                = LP()->settings->get( "{$this->id}.title", $this->method_title );
			$this->description          = LP()->settings->get( "{$this->id}.description", $this->method_description );


			if ( did_action( 'learn_press/digipay-add-on/loaded' ) ) {
				return;
			}

			// check payment gateway enable
			add_filter( 'learn-press/payment-gateway/' . $this->id . '/available', array(
				$this,
				'digipay_available'
			), 10, 2 );

			do_action( 'learn_press/digipay-add-on/loaded' );

			parent::__construct();

			// web hook
			if ( did_action('init')) {
				$this->register_web_hook();
			} else {
				add_action( 'init', array( $this, 'register_web_hook' ) );
			}
			add_action( 'learn_press_web_hooks_processed', array( $this, 'web_hook_process_digipay' ) );

			add_action("learn-press/before-checkout-order-review", array( $this, 'error_message' ));
		}

        public function initDP()
        {
            $settings = LP()->settings;

            return new DPGateway([
                'type'              => $settings->get("{$this->id}.type"),
                'username'          => $settings->get("{$this->id}.username"),
                'password'          => $settings->get("{$this->id}.password"),
                'client_id'         => $settings->get("{$this->id}.client_id"),
                'client_secret'     => $settings->get("{$this->id}.client_secret"),
                'access_token'      => $settings->get("{$this->id}.access_token"),
                'refresh_token'     => $settings->get("{$this->id}.refresh_token"),

            ],function ($accessToken, $refreshToken) use($settings) {
                $settings->set("{$this->id}.access_token",  $accessToken);
                $settings->set("{$this->id}.refresh_token", $refreshToken);
            });
		}

		public function register_web_hook() {
			learn_press_register_web_hook( 'digipay', 'learn_press_digipay' );
		}

		public function get_settings() {

			return apply_filters( 'learn-press/gateway-payment/digipay/settings',
				array(
					array(
						'title'   => 'Enable',
						'id'      => '[enable]',
						'default' => 'no',
						'type'    => 'yes-no'
					),
					array(
						'type'       => 'text',
						'title'      => 'Title',
						'default'    => 'Digipay',
						'id'         => '[title]',
						'class'      => 'regular-text',
						'visibility' => array(
							'state'       => 'show',
							'conditional' => array(
								array(
									'field' => '[enable]',
									'compare' => '=',
									'value'   => 'yes'
								)
							)
						)
					),
					array(
						'type'       => 'textarea',
						'title'      => 'Description',
						'default'    => 'Pay with Digipay',
						'id'         => '[description]',
						'editor'     => array(
							'textarea_rows' => 5
						),
						'css'        => 'height: 100px;',
						'visibility' => array(
							'state'       => 'show',
							'conditional' => array(
								array(
									'field' => '[enable]',
									'compare' => '=',
									'value'   => 'yes'
								)
							)
						)
					),
					[
                        'title'      => 'username',
                        'id'         => '[username]',
                        'type'       => 'text',
                        'visibility' => ['state' => 'show', 'conditional' => [['field' => '[enable]', 'compare' => '=', 'value'   => 'yes']]
                        ]
                    ],
                    [
                        'title'      => 'password',
                        'id'         => '[password]',
                        'type'       => 'text',
                        'visibility' => ['state' => 'show', 'conditional' => [['field' => '[enable]', 'compare' => '=', 'value'   => 'yes']]
                        ]
                    ],
                    [
                        'title'      => 'client_id',
                        'id'         => '[client_id]',
                        'type'       => 'text',
                        'visibility' => ['state' => 'show', 'conditional' => [['field' => '[enable]', 'compare' => '=', 'value'   => 'yes']]
                        ]
                    ],
                    [
                        'title'      => 'client_secret',
                        'id'         => '[client_secret]',
                        'type'       => 'text',
                        'visibility' => ['state' => 'show', 'conditional' => [['field' => '[enable]', 'compare' => '=', 'value'   => 'yes']]
                        ]
                    ],
				)
			);
		}

		public function get_payment_form() {
			ob_start();
            include learn_press_locate_template( 'form.php', learn_press_template_path() . '/addons/digipay-payment/', LP_ADDON_DIGIPAY_PAYMENT_TEMPLATE );
			return ob_get_clean();
		}

		public function error_message() {
			if(!isset($_SESSION)){
                session_start();
            }
			if(isset($_SESSION['digipay_error']) && intval($_SESSION['digipay_error']) === 1) {
				$_SESSION['digipay_error'] = 0;
                include learn_press_locate_template( 'payment-error.php', learn_press_template_path() . '/addons/digipay-payment/', LP_ADDON_DIGIPAY_PAYMENT_TEMPLATE );
			}
		}

		public function digipay_available() {

		    return LP()->settings->get( "{$this->id}.enable" ) == 'yes';
		}

		public function get_form_data() {
			if ($this->order) {
				$user               = learn_press_get_current_user();
				$currency_code      = learn_press_get_currency();

				if($currency_code == 'IRR'){
					$amount = $this->order->order_total ;
				}else{
					$amount = $this->order->order_total * 10 ;
				}

				$this->form_data = [
                    'amount'      => $amount,
                    'currency'    => strtolower(learn_press_get_currency()),
                    'token'       => $this->token,
                    'description' => sprintf( "Charge for %s" , $user->get_data('email')),
                    'customer'    => array(
                        'name'          => $user->get_data('display_name'),
                        'billing_email' => $user->get_data('email'),
                    ),
                    'errors'      => isset( $this->posted['form_errors'] ) ? $this->posted['form_errors'] : ''
                ];
			}

			return $this->form_data;
		}

		public function validate_fields() {
			$posted        = learn_press_get_request( 'learn-press-digipay' );
			$email   = !empty( $posted['email'] ) ? $posted['email'] : "";
			$mobile  = !empty( $posted['mobile'] ) ? $posted['mobile'] : "";
			$error_message = array();
			if ( !empty( $email ) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
				$error_message[] = 'Invalid email format.';
			}
			if ( !empty( $mobile ) && !preg_match("/^(09)(\d{9})$/", $mobile)) {
				$error_message[] = 'Invalid mobile format.';
			}

			if ( $error = sizeof( $error_message ) ) {
				throw new Exception( sprintf( '<div>%s</div>', join( '</div><div>', $error_message ) ), 8000 );
			}
			$this->posted = $posted;

			return $error ? false : true;
		}

		public function process_payment($order) {

			$this->order    = learn_press_get_order($order);
			$callbackUrl    = get_site_url() . '/?' . learn_press_get_web_hook( 'digipay' ) . '=1&order_id='.$this->order->get_id();

			$dp             = $this->initDP();

			try {
                $url        = $dp->createTicket($this->form_data['amount'], $this->order->get_id(), $callbackUrl, (!empty($this->posted['mobile'])) ? $this->posted['mobile'] : null);
                $success    = true;

            }catch (Exception $e){
			    $success    = false;
            }

			return [
                'result'        => $success ? 'success' : 'fail',
                'redirect'      => $success ? $url : ''
            ];
		}

		public function web_hook_process_digipay() {
			$request = $_REQUEST;
			if(isset($request['learn_press_digipay']) && intval($request['learn_press_digipay']) === 1) {

                $result         = $_POST['result'];
                $amount         = $_POST['amount'];
                $providerId     = $_POST['providerId'];
                $trackingCode   = $_POST['trackingCode'];

                if ($result == 'SUCCESS') {
                    $order = LP_Order::instance($request['order_id']);
                    $currency_code = learn_press_get_currency();

                    $dp = $this->initDP();
                    try {
                        $dp->verifyTicket($trackingCode);
                        $this->payment_status_completed($order, $trackingCode);
                        wp_redirect(esc_url($this->get_return_url($order)));
                        exit();
                    } catch (Exception $e) {
                        if (!isset($_SESSION))
                            session_start();
                        $_SESSION['digipay_error'] = 1;

                        wp_redirect(esc_url(learn_press_get_page_link('checkout')));
                        exit();
                    }
                }
			}
		}

		protected function payment_status_completed( $order, $tracking_code ) {

		    if($order->has_status('completed')){
				exit;
			}

			$this->payment_complete( $order, $tracking_code, 'Payment has been successfully completed' );
			update_post_meta( $order->get_id(), '_digipay_RefID', $tracking_code );
		}

		public function payment_complete( $order, $trans_id = '', $note = '' ) {
			$order->payment_complete($trans_id);
		}
	}
}
