<?php
/*
Plugin Name: Digipay WP-donate
Plugin URI: https://mydigipay.com
Description: افزونه حمایت مالی از طریق درگاه هوشمند دیجی پی
Version: 1.0
Author:  myDigipay
Author URI: http://mydigipay.com
*/

if(!class_exists("DPGateway")){
  include_once "lib/DPGateway.php";
}

defined('ABSPATH') or die();

add_action( 'init', 'dp_add_short_code');
register_activation_hook(__FILE__,'dp_install');

if (is_admin()) {

  add_action('admin_menu', 'EZD_AdminMenuItem');

  function EZD_AdminMenuItem()
  {
    add_menu_page( 'تنظیمات حمایت مالی - درگاه دیجی پی', 'حمایت مالی', 'administrator', 'DP_menu', 'dp_donate_setting', '', 6);
    add_submenu_page('DP_menu','لیست حامیان','لیست حامیان', 'administrator','DP_donates','dp_donate_list');

  }
}

function dp_init_payment(){
  return new DPGateway([

      'type'            => get_option( 'dp_donate_type'),
      'username'        => get_option( 'dp_donate_username'),
      'password'        => get_option( 'dp_donate_password'),
      'client_id'       => get_option( 'dp_donate_client_id'),
      'client_secret'   => get_option( 'dp_donate_client_secret'),
      'access_token'    => get_option( 'dp_donate_access_token'),
      'refresh_token'   => get_option( 'dp_donate_refresh_token'),

  ],function ($accessToken, $refreshToken){
    update_option('dp_donate_access_token',  $accessToken);
    update_option('dp_donate_refresh_token', $refreshToken);
  });
}

function dp_donate_setting()
{
	include('lib/dp_donate_setting.php');
}

function dp_donate_list()
{
	include('lib/dp_donate_list.php');
}

function dp_add_short_code(){
	add_shortcode('dp_donate', 'dp_generate_form');
}

function dp_generate_form() {

    $error = [];

  //submit
  if(!empty($_POST['dp_submit'])){

    $amount         = filter_input(INPUT_POST, 'dp_amount', FILTER_SANITIZE_SPECIAL_CHARS);
    $description    = filter_input(INPUT_POST, 'dp_description', FILTER_SANITIZE_SPECIAL_CHARS);
    $name           = filter_input(INPUT_POST, 'dp_name', FILTER_SANITIZE_SPECIAL_CHARS);
    $mobile         = filter_input(INPUT_POST, 'dp_mobile', FILTER_SANITIZE_SPECIAL_CHARS);
    $email          = filter_input(INPUT_POST, 'dp_email', FILTER_SANITIZE_SPECIAL_CHARS);

    if(empty(get_option( 'dp_donate_username'))){
      $error[] = 'اطلاعات درگاه پرداخت دیجی پی تکمیل نشده است';
    }

    if(empty($amount) || !is_numeric($amount)){
      $error[] = 'مبلغ وارد شده صحیح نیست';
    }

    if(empty($name)){
        $error[] = 'نام خود را وارد کنید';
    }

    if(count($error) == 0) {

      $callbackURL  = dp_get_callback_url();
      $dp           = dp_init_payment();
      $res_id       = rand(1000000,9999999);

      try {
          if(empty($mobile)){
              $mobile = null;
          }
          $res = $dp->createTicket($amount, $res_id, $callbackURL, $mobile, false);

        dp_add_record([
            'tracking_code' => $res['ticket'],
            'res_id'        => $res_id,
            'name'          => $name,
            'amount'        => $amount,
            'mobile'        => $mobile,
            'email'         => $email,
            'created_at'    => current_time('mysql'),
            'description'   => $description,
            'status'        => 'pending'
        ]);

        ?>
          <script>
              window.location = '<?php echo $res['url'] ?>';
          </script>
        <?php

      }catch (Exception $e){

        echo $e->getMessage();
        die();

      }
    }
  }

  //verify
  if(!empty($_POST['trackingCode'])){

    $result         = $_POST['result'];
    $amount         = $_POST['amount'];
    $providerId     = $_POST['providerId'];
    $trackingCode   = $_POST['trackingCode'];

    if($result == 'SUCCESS') {

      $record = dp_get_record($trackingCode);

      if(!$record){
        $error[] = 'این تراکنش ثبت نشده است';

      }elseif($record['status'] != 'pending') {
        $error[] = 'این تراکنش قبلا تایید شده است';

      }else{

        $dp = dp_init_payment();
        try {
          $dp->verifyTicket($trackingCode);
          dp_change_record_status($trackingCode, 'payed');

        } catch (Exception $e) {
          $error[] = $e->getMessage();
        }

      }

    }else{

      $error[] = 'تراکنش توسط کاربر بازگشت خورد';
      dp_change_record_status($trackingCode, 'cancelled');

    }
  }

    ob_start();
    include "lib/form.php";
    $out = ob_get_clean();

    return $out;
}

function dp_install()
{

  global $wpdb;

  $wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix . 'dp_donate'."` (`id` int(11) NOT NULL AUTO_INCREMENT,`tracking_code` varchar(100) NOT NULL,`res_id` varchar(100) NOT NULL,`name` varchar(50) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,`amount` int(11) NOT NULL,`mobile` varchar(11) ,`email` varchar(50),`created_at` varchar(20),`description` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci,`status` varchar(50),PRIMARY KEY (`id`),KEY `id` (`id`)) DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

  add_option("dp_donate_username");
  add_option("dp_donate_password");
  add_option("dp_donate_client_id");
  add_option("dp_donate_client_secret");
  add_option("dp_donate_type");
  add_option("dp_donate_access_token");
  add_option("dp_donate_refresh_token",   '', '', 'yes');

}

function dp_get_record($tracking_code)
{
  global $wpdb;

  $tracking_code = strip_tags($wpdb->escape($tracking_code));

  if(empty($tracking_code)){
    return false;
  }

  $res = $wpdb->get_results( "SELECT * FROM `".$wpdb->prefix . 'dp_donate'."` WHERE tracking_code = '${$tracking_code}' LIMIT 1",ARRAY_A);

  if(count($res) == 0)
    return false;

  return $res[0];
}

function dp_add_record($data)
{
  global $wpdb;

  if(!is_array($data)){
    return false;
  }

  $wpdb->insert( $wpdb->prefix . 'dp_donate' , $data);
}

function dp_change_record_status($tracking_code,$status)
{
  global $wpdb;

  $tracking_code  = strip_tags($wpdb->escape($tracking_code));
  $status         = strip_tags($wpdb->escape($status));

  if(empty($tracking_code) || empty($status)){
    return false;
  }


  $res = $wpdb->query( "UPDATE `". $wpdb->prefix . 'dp_donate' ."` SET `status` = '${status}' WHERE `tracking_code` = '${tracking_code}'");

  return $res;
}

function dp_get_callback_url()
{
  $pageURL = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";

  $ServerName = htmlspecialchars($_SERVER["SERVER_NAME"], ENT_QUOTES, "utf-8");
  $ServerPort = htmlspecialchars($_SERVER["SERVER_PORT"], ENT_QUOTES, "utf-8");
  $ServerRequestUri = htmlspecialchars($_SERVER["REQUEST_URI"], ENT_QUOTES, "utf-8");

  if ($_SERVER["SERVER_PORT"] != "80")
  {
      $pageURL .= $ServerName .":". $ServerPort . $_SERVER["REQUEST_URI"];
  }
  else
  {
      $pageURL .= $ServerName . $ServerRequestUri;
  }
  return $pageURL;
}
