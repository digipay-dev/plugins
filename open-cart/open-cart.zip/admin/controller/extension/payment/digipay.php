<?php
class ControllerExtensionPaymentDigipay extends Controller {
	private $error = [];

	public function index() {
		$this->load->language('extension/payment/digipay');
		$this->load->model('localisation/order_status');

		$this->document->setTitle("Digipay");
		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('payment_digipay', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = [
			[
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
			],
			[
				'text' => $this->language->get('text_extension'),
				'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
			],
			[
				'text' => 'Digipay',
				'href' => $this->url->link('extension/payment/digipay', 'user_token=' . $this->session->data['user_token'], true)
			]
		];

		$data['action'] 							= $this->url->link('extension/payment/digipay', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] 							= $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);
		$data['payment_digipay_type'] 				= $this->config->get('payment_digipay_type');
		$data['payment_digipay_username'] 			= $this->config->get('payment_digipay_username');
		$data['payment_digipay_password'] 			= $this->config->get('payment_digipay_password');
		$data['payment_digipay_client_id'] 			= $this->config->get('payment_digipay_client_id');
		$data['payment_digipay_client_secret'] 		= $this->config->get('payment_digipay_client_secret');
		$data['payment_digipay_order_status_id'] 	= $this->config->get('payment_digipay_order_status_id');
		$data['payment_digipay_sort_order'] 		= $this->config->get('payment_digipay_sort_order');
		$data['header'] 							= $this->load->controller('common/header');
		$data['column_left'] 						= $this->load->controller('common/column_left');
		$data['footer'] 							= $this->load->controller('common/footer');
		$data['order_statuses'] 					= $this->model_localisation_order_status->getOrderStatuses();



		$this->response->setOutput($this->load->view('extension/payment/digipay', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/digipay')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}
?>
