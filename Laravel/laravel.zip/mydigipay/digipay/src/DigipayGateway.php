<?php

namespace MyDigipay\Digipay;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Kamva\Crud\Exceptions\DigipayException;
use MyDigipay\Digipay\DPGateway;

class DigipayGateway
{
    private $amount;
    private $callback;
    private $url;
    private $ticket;

    /**
     * DigipayGateway constructor.
     * @param int       $amount
     * @param string    $callback
     */
    public function __construct($amount = null, $callback = null)
    {
        $this->amount       = $amount;
        $this->callback     = $callback;
    }

    /**
     * @param int $amount
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;
    }

    /**
     * @param string $callback
     */
    public function setCallback($callback)
    {
        $this->callback = $callback;
    }

    private function initDP()
    {
        $settings = [
            'type'              => config('digipay.type'),
            'username'          => config('digipay.username'),
            'password'          => config('digipay.password'),
            'client_id'         => config('digipay.client_id'),
            'client_secret'     => config('digipay.client_secret'),
            'access_token'      => Cache::get('dp_access_token'),
            'refresh_token'     => Cache::get('dp_refresh_token'),
        ];

        return new DPGateway($settings , function ($accessToken, $refreshToken){

            Cache::forever('dp_access_token',  $accessToken);
            Cache::forever('dp_refresh_token', $refreshToken);

        });
    }

    public function prepare($refID, $mobile)
    {
        $dp             = $this->initDP();

        $ticket         = $dp->createTicket($this->amount, $refID, $this->callback, $mobile);

        $this->ticket   = $ticket['ticket'];
        $this->url      = $ticket['url'];
    }

    public function redirect()
    {
        if(empty($this->url)){
            throw new DigipayException("Run Prepare method first.");
        }

        return redirect($this->url);
    }

    public function getTicket()
    {
        if(empty($this->ticket)){
            throw new DigipayException("Run Prepare method first.");
        }

        return $this->ticket;
    }

    public function verify(Request $request)
    {
        $result         = $request->input('result');
        $amount         = $request->input('amount');
        $providerId     = $request->input('providerId');
        $trackingCode   = $request->input('trackingCode');

        if($result != 'SUCCESS'){
            throw new DigipayException("Transaction cancelled");
        }

        $dp = $this->initDP();

        $dp->verifyTicket($trackingCode);

        return [
            'provider_id'   => $providerId,
            'tracking_code' => $trackingCode,
            'amount'        => $amount,
            'result'        => $result
        ];
    }
}
