<?php
if (!defined('WHMCS'))
{
    die('access denied');
}

function digipay_MetaData()
{
    return [
        'DisplayName'                   => 'Digipay',
        'APIVersion'                    => '1.0.0',
        'DisableLocalCredtCardInput'    => true,
        'TokenisedStorage'              => false
    ];
}

function digipay_config()
{
    return [
        'FriendlyName' => [
            'Type'  => 'System',
            'Value' => 'درگاه پرداخت هوشمند دیجی پی'
        ],
        'type' => [
            'FriendlyName' => 'نوع درگاه',
            'Type'         => 'dropdown',
            'Options'      => [
                'IPG'     => 'درگاه پرداخت هوشمند (IPG)',
                'UPG'     => 'درگاه پرداخت جامع (UPG)',
                'WPG'     => 'درگاه کیف پولی (WPG)',
            ]
            ,
            'Description'  =>  '<br><br>IPG - درگاه پرداخت هوشمند دیجی پی که با استفاده از الگوریتم های مختلف بهترین درگاه را در لحظه برای مشتری شما انتخاب می کند <Br><Br>WPG - درگاه پرداخت کیف پولی دیجی پی که امکان پرداخت از طریق کیف پول دیجی پی را برای مشتریان شما فراهم می کند <Br><Br>UPG - درگاه پرداخت جامع دیجی پی که ترکیبی از درگاه هوشمند و کیف پول را در خود دارد،  اگر کیف پول کسب و کاری شما راه اندازی شده پیشنهاد ما استفاده از این روش پرداخت است.',
        ],

        'username' => [
            'FriendlyName' => 'username',
            'Type'         => 'text',
            'Default'      => null,
            'Description'  => null
        ],
        'password' => [
            'FriendlyName' => 'password',
            'Type'         => 'text',
            'Default'      => null,
            'Description'  => null
        ],
        'client_id' => [
            'FriendlyName' => 'client ID',
            'Type'         => 'text',
            'Default'      => null,
            'Description'  => null
        ],
        'client_secret' => [
            'FriendlyName' => 'client Secret',
            'Type'         => 'text',
            'Default'      => null,
            'Description'  => null
        ],

        'currencyType' => [
            'FriendlyName' => 'واحد پول',
            'Type'         => 'dropdown',
            'Options'      => ['Rial' => 'ریال' , 'Toman' => 'تومان'],
            'Description'  => null
        ]
    ];
}

function digipay_link($params)
{
    $username           = $params['username'];
    $password           = $params['password'];
    $client_id          = $params['client_id'];
    $client_secret      = $params['client_secret'];

    $currencyType       = $params['currencyType'];

    $invoiceId          = $params['invoiceid'];
    $description        = $params['description'];
    $amount             = $params['amount'];
    $currency           = $params['currency'];

    $firstName          = $params['clientdetails']['firstname'];
    $lastName           = $params['clientdetails']['lastname'];
    $email              = $params['clientdetails']['email'];
    $address1           = $params['clientdetails']['address1'];
    $address2           = $params['clientdetails']['address2'];
    $city               = $params['clientdetails']['city'];
    $state              = $params['clientdetails']['state'];
    $postCode           = $params['clientdetails']['postcode'];
    $country            = $params['clientdetails']['country'];
    $phone              = $params['clientdetails']['phonenumber'];

    $companyName        = $params['companyname'];
    $systemUrl          = $params['systemurl'];
    $returnUrl          = $params['returnurl'];
    $langPayNow         = $params['langpaynow'];
    $moduleDisplayName  = $params['name'];
    $moduleName         = $params['paymentmethod'];
    $whmcsVersion       = $params['whmcsVersion'];

    $paymentAmount = round($amount);

    if ($currencyType == 'Toman'){
        $paymentAmount = round($paymentAmount * 10);
    }

    $url  = $systemUrl . 'modules/gateways/' . $moduleName . '/request.php?hash='.uniqid();
    $hash = md5( $paymentAmount . $client_secret);

    $postFields = [];

    $postFields['invoice_id']       = $invoiceId;
    $postFields['amount']           = $paymentAmount;
    $postFields['currency']         = $currency;
    $postFields['callback']         = $systemUrl . 'modules/gateways/callback/'.$moduleName.'.php?secure='.$invoiceId.'-'.$hash;
    $postFields['return_url']       = $returnUrl;
    $postFields['mobile']           = $phone;

    $htmlOutput = '<form id="gateway" name="gateway" method="post" action="' . $url . '">';

    foreach ($postFields as $key => $value) {

        $htmlOutput .= '<input id="' . $key . '" name="' . $key . '" type="hidden" value="' . $value . '" />';
    }

    $htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';

    return $htmlOutput;
}
