<?php
/**
 * @package     Joomla - > Site and Administrator payment info
 * @subpackage  com_Jshopping
 * @subpackage 	mydigipay_Digipay
 * @copyright   MyDigipay => https://mydigipay.com
 * @copyright   Copyright (C) 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die();

require_once dirname(__FILE__). '/DPGateway.php';


class pm_Digipay extends PaymentRoot{

    function showPaymentForm($params, $pmconfigs){
        include(dirname(__FILE__)."/paymentform.php");
    }

    function storeData($key,$value,$params)
    {
        $payment                    = $this->getPmMethod();
        $params[$key]               = $value;
        $parseString                = new parseString($params);
        $payment->payment_params    = $parseString->splitParamsToString();
        $payment->store();
    }

	function showAdminFormParams($params){
		$array_params = [
            'transaction_end_status',
            'transaction_pending_status',
            'transaction_failed_status',
            'type'
        ];

		foreach ($array_params as $key){
			if(empty($params[$key])){
                $params[$key] = '';
            }
		}

		$orders = JSFactory::getModel('orders');

        include(dirname(__FILE__)."/adminparamsform.php");
	}

	function showEndForm($pmconfigs, $order){
		$app	= JFactory::getApplication();
        $uri = JURI::getInstance();
        $pm_method = $this->getPmMethod();
        $liveurlhost = $uri->toString(array("scheme",'host', 'port'));
        $return = $liveurlhost . SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=".$pm_method->payment_class).'&orderId='. $order->order_id;
    	$notify_url2 = $liveurlhost . SEFLink("index.php?option=com_jshopping&controller=checkout&task=step2&act=notify&js_paymentclass=".$pm_method->payment_class."&no_lang=1");

        $CallbackURL    = $return;


		if (!isset($pmconfigs['username']) || $pmconfigs['username'] == '') {
			$app->redirect($notify_url2, '<h2>لطفا تنظیمات درگاه دیجی پی را بررسی کنید</h2>', $msgType='Error');
		}

        $dp = $this->initDP($pmconfigs);
		try {
		    $url = $dp->createTicket(round($this->fixOrderTotal($order)), '', $CallbackURL);
            Header('Location: ' . $url);

        }
		catch(Exception $e) {
			$msg    = $e->getMessage();
			$app	= JFactory::getApplication();
			$app->redirect($notify_url2, '<h2>'.$msg.'</h2>', $msgType='Error');
		}
	}

	function initDP($pmConfigs){

        return new DPGateway([
            'type'          => $pmConfigs['type'],
            'username'      => $pmConfigs['username'],
            'password'      => $pmConfigs['password'],
            'client_id'     => $pmConfigs['client_id'],
            'client_secret' => $pmConfigs['client_secret'],
            'access_token'  => $pmConfigs['access_token'],
            'refresh_token' => $pmConfigs['refresh_token']
        ] , function ($accessToken, $refreshToken) use($pmConfigs){

            $this->storeData('access_token',  $accessToken,  $pmConfigs);
            $this->storeData('refresh_token', $refreshToken, $pmConfigs);
        });

    }

    function checkTransaction($pmconfigs, $order, $act){

        $app	        = JFactory::getApplication();
        $jinput         = $app->input;
        $uri            = JURI::getInstance();
        $pm_method      = $this->getPmMethod();
        $liveurlhost    = $uri->toString(array("scheme",'host', 'port'));
        $cancel_return  = $liveurlhost.SEFLink("index.php?option=com_jshopping&controller=checkout&task=step7&act=cancel&js_paymentclass=".$pm_method->payment_class).'&orderId='. $order->order_id;
        $result         = $jinput->get->get('result', 'STRING');
        $amount         = $jinput->get->get('amount', 'STRING');
        $providerId     = $jinput->get->get('providerId', 'STRING');
        $trackingCode   = $jinput->get->get('trackingCode', 'STRING');


        if ($result == 'SUCCESS') {
            try {
                $dp = $this->initDP($pmconfigs);
                $dp->verifyTicket($trackingCode);

                $msg        = 'پرداخت با موفقیت انجام شد';
                $message    = "کد پیگیری".$trackingCode."<br>" ."شماره سفارش ".$order->order_id;
                $app->enqueueMessage($message, 'message');
                saveToLog("payment.log", "Status Complete. Order ID ".$order->order_id.". message: ".$msg . " status_code: " . $trackingCode);
                return array(1, "");

            }
            catch(Exception $e) {
                $msg= $e->getMessage();
                saveToLog("payment.log", "Status failed. Order ID ".$order->order_id.". message: ".$msg );
                $app->redirect($cancel_return, '<h2>'.$msg.'</h2>' , $msgType='Error');
            }
        }
        else {
            $msg= 'کاربر از انجام تراکنش منصرف شده است';
            saveToLog("payment.log", "Status Cancelled. Order ID ".$order->order_id.". message: ".$msg );
            $app->redirect($cancel_return, '<h2>'.$msg.'</h2>' , $msgType='Error');
        }
	}

    function getUrlParams($pmconfigs){
		$app	= JFactory::getApplication();
		$jinput = $app->input;
		$oId = $jinput->get->get('orderId', '0', 'INT');
        $params = array();
        $params['order_id'] = $oId;
        $params['hash'] = "";
        $params['checkHash'] = 0;
        $params['checkReturnParams'] = 1;
		return $params;
    }

	function fixOrderTotal($order){
        $total = $order->order_total;
        if ($order->currency_code_iso=='HUF'){
            $total = round($total);
        }else{
            $total = number_format($total, 2, '.', '');
        }
    return $total;
    }
}
