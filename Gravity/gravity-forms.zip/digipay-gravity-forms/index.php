<?php
/*
Plugin Name: پرداخت digipay برای gravityforms
Plugin URI: https://mydigipay.com/
Description: افزونه درگاه پرداخت دیجی پی برای  gravityforms
Version: 1.0.0
Author: Digipay
Author URI: https://mydigipay.com/
*/
if (!defined('ABSPATH')){
    exit;
}

require_once('digipay.php');
