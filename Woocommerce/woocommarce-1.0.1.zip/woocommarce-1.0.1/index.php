<?php
/*
Plugin Name: درگاه پرداخت دیجی پی برای ووکامرس
Version: 1.0.1
Description: درگاه پرداخت دیجی پی برای پرداخت آنلاین در فروشگاه ووکامرس
Plugin URI: https://www.mydigipay.com/
Author: Digipay
Author URI: https://www.mydigipay.com/

*/
include_once("wc-dp-gateway.php");
