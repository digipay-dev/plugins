<?php
return [
    'type'          => env('DIGIPAY_TYPE', 'IPG'),
    'username'      => env('DIGIPAY_USERNAME'),
    'password'      => env('DIGIPAY_PASSWORD'),
    'client_id'     => env('DIGIPAY_CLIENT_ID'),
    'client_secret' => env('DIGIPAY_CLIENT_SECRET'),
];
