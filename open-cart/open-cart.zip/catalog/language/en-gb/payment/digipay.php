<?php
// Text
$_['text_title'] 		    = 'Digipay';
$_['text_wait']  		    = 'Please Wait!';
$_['text_connect'] 		    = 'Connecting To Digipay';
$_['text_results']  	    = 'Digipay Tracking code : ';
$_['button_view_cart']	    = 'View Shopping Cart';
$_['button_complete']       = 'Complete Payment';
$_['error_order_id']	    = 'Order Id Not Found !';
$_['error_verify']	        = 'User Cancelled the transaction';
