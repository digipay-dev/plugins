<?php
use WHMCS\Database\Capsule;

require_once(__DIR__ . '/../../../init.php');
require_once(__DIR__ . '/../../../includes/gatewayfunctions.php');
require_once(__DIR__ . '/../../../includes/invoicefunctions.php');

$gatewayParams = getGatewayVariables('digipay');

if ($gatewayParams['type'] == false)
{
    die('Module Not Activated');
}

$invoiceId = null;

if (isset($_GET['secure'])){
    $secure         = explode('-' , $_GET['secure']);
    $invoiceId      = $secure[0];
    $secure         = $secure[1];

    $result         = $_POST['result'];
    $amount         = $_POST['amount'];
    $providerId     = $_POST['providerId'];
    $trackingCode   = $_POST['trackingCode'];

    $hash           = md5($amount . $gatewayParams['client_secret']);

    if (!empty($invoiceId) && $result == 'SUCCESS' && $secure == $hash){

        $dp             = new DPGateway([
            'username'          => $gatewayParams['username'],
            'password'          => $gatewayParams['password'],
            'client_id'         => $gatewayParams['client_id'],
            'client_secret'     => $gatewayParams['client_secret'],
            'type'              => $gatewayParams['type'],

        ], function ($accessToken, $refreshToken){});

        try {

            if (Capsule::table('tblinvoices')->where('id', $invoiceId)->where('status', 'Paid')->count() > 0) {

                logTransaction($gatewayParams['name'], [
                    'Code'    => 'Double Spending',
                    'Message' => 'تایید تراکنش در گذشته با موفقیت انجام شده است'
                ], 'Failure');

            }else{

                if ($gatewayParams['currencyType'] == 'Toman'){
                    $amount = round($amount / 10);
                }

                $dp->verifyTicket($trackingCode);

                addInvoicePayment($invoiceId , $trackingCode , $amount , 0 , 'digipay');

                logTransaction($gatewayParams['name'], [
                    'Message'     => 'تراکنش با موفقیت انجام شد',
                    'Transaction' => $trackingCode,
                    'Amount'      => $amount,
                ], 'Success');
            }
        }catch (Exception $e){

            logTransaction($gatewayParams['name'], [
                'Code'        => 'Verify' ,
                'Message'     => $e->getMessage() ,
                'Transaction' => $trackingCode,
                'Invoice'     => $invoiceId
            ], 'Failure');
        }
    }else{
        logTransaction($gatewayParams['name'] ,[
            'Code' => 'Invalid Data' ,
            'Message' => 'اطلاعات ارسال شده مربوط به تایید تراکنش ناقص و یا غیر معتبر است'
        ], 'Failure');
    }
}else{
    logTransaction($gatewayParams['name'] , [
        'Code'      => 'Invalid Data' ,
        'Message'   => 'اطلاعات ارسال شده مربوط به تایید تراکنش ناقص و یا غیر معتبر است'
    ], 'Failure');
}

$invoiceId ? header('Location: '.$gatewayParams['systemurl'].'viewinvoice.php?id='.$invoiceId) : header('Location: '.$gatewayParams['systemurl'].'clientarea.php?action=invoices');
exit();
