<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Digipay\Digipay\Model\Config\Source\Gateway\GatewayType;

/**
 * @api
 * @since 100.0.2
 */
class GatewayType implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => 'IPG',
                'label' => 'درگاه پرداخت هوشمند (IPG)'
            ],
            [
                'value' => 'UPG',
                'label' => 'درگاه پرداخت جامع (UPG)'
            ],
            [
                'value' => 'WPG',
                'label' => 'درگاه کیف پولی (WPG)'
            ]
        ];
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {

        return [
            'IPG'     => 'درگاه پرداخت هوشمند (IPG)',
            'UPG'     => 'درگاه پرداخت جامع (UPG)',
            'WPG'     => 'درگاه کیف پولی (WPG)'
        ];
    }
}
