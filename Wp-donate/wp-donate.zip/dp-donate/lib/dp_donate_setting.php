<?php

defined('ABSPATH') or die();

if ($_POST){

    update_option( 'dp_donate_type',            $_POST['dp_donate_type']);
    update_option( 'dp_donate_username',        $_POST['dp_donate_username']);
    update_option( 'dp_donate_password',        $_POST['dp_donate_password']);
    update_option( 'dp_donate_client_id',       $_POST['dp_donate_client_id']);
    update_option( 'dp_donate_client_secret',   $_POST['dp_donate_client_secret']);
    update_option( 'dp_donate_access_token',    '');
    update_option( 'dp_donate_refresh_token',   '');

}
?>
<h2 id="add-new-user">تنظیمات پلاگین حمایت مالی - درگاه دیجی پی</h2>

<br>
<span>برای نمایش فرم حمایت مالی در پست و یا صفحه مقدار کدکوتاه <code>[dp_donate/]</code> را داخل صفحه قرار دهید</span>
<br>

<form method="post">
  <table class="form-table">
    <tbody>
    <tr>
        <th><label>type</label></th>
        <td>
            <select class="regular-text" name="dp_donate_type">
                <option value="IPG" <?php if(get_option( 'dp_donate_type') == 'IPG'){ ?> selected <?php } ?> >درگاه پرداخت هوشمند (IPG)</option>
                <option value="UPG" <?php if(get_option( 'dp_donate_type') == 'UPG'){ ?> selected <?php } ?> >درگاه پرداخت جامع (UPG)</option>
                <option value="WPG" <?php if(get_option( 'dp_donate_type') == 'WPG'){ ?> selected <?php } ?> >درگاه کیف پولی (WPG)</option>
            </select>
        </td>
    </tr>
    <tr>
        <th><label>username</label></th>
        <td>
          <input type="text" class="regular-text" value="<?php echo get_option( 'dp_donate_username'); ?>" name="dp_donate_username">
        </td>
    </tr>
    <tr>
      <th><label>password</label></th>
      <td>
          <input type="text" class="regular-text" value="<?php echo get_option( 'dp_donate_password'); ?>" name="dp_donate_password">
      </td>
    </tr>
    <tr>
      <th><label>client ID</label></th>
      <td>
          <input type="text" class="regular-text" value="<?php echo get_option( 'dp_donate_client_id'); ?>" name="dp_donate_client_id">
      </td>
    </tr>
    <tr>
      <th><label>client Secret</label></th>
      <td>
          <input type="text" class="regular-text" value="<?php echo get_option( 'dp_donate_client_secret'); ?>" name="dp_donate_client_secret">
      </td>
    </tr>

    </tbody>
  </table>
  <p class="submit"><input type="submit" value="ذخیره" class="button button-primary" id="submit" name="submit"></p>
</form>


