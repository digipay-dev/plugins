<?php
/*
Plugin Name: LearnPress - Digipay Payment
Plugin URI: https://mydigipay.com/
Description: Digipay payment for LearnPress.
Author: Digipay
Version: 1.0
Author URI: https://mydigipay.com
*/

defined( 'ABSPATH' ) || exit;

define( 'LP_ADDON_DIGIPAY_PAYMENT_FILE', __FILE__ );
define( 'LP_ADDON_DIGIPAY_PAYMENT_VER', '1.0.0' );
define( 'LP_ADDON_DIGIPAY_PAYMENT_REQUIRE_VER', '1.0.0' );

class LP_Addon_Digipay_Payment_Preload {

	public function __construct() {
		add_action( 'learn-press/ready', [$this, 'load'] );
		add_action( 'admin_notices', [$this, 'admin_notices'] );
	}

	public function load() {
		LP_Addon::load( 'LP_Addon_Digipay_Payment', 'inc/load.php', __FILE__ );
		remove_action( 'admin_notices', array( $this, 'admin_notices' ) );
	}

	public function admin_notices() {
		?>
        <div class="error">
            <p><?php echo wp_kses(
                    '<strong>Digipay Payment</strong> addon version is incompatible with this learnpress version</strong>.',
					array(
						'a'      => array(
							'href'  => array(),
							'blank' => array()
						),
						'strong' => array()
					)
				); ?>
            </p>
        </div>
		<?php
	}
}

new LP_Addon_Digipay_Payment_Preload();
