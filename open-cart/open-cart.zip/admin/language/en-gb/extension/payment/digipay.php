<?php
$_['heading_title']       = 'Digipay';
$_['text_wait']           = 'Please wait.';
$_['text_extension']	  = 'Extensions';
$_['text_success']        = 'Success';
$_['text_digipay']  	  = '<a href="http://www.mydigipay.com" target="_blank"><img src="view/image/payment/digipay.png" alt="Digipay" title="Digipay" style="height: 60px"/></a>';
$_['text_edit']           = 'Edit Digipay';
$_['entry_order_status']  = 'Order Status';
$_['entry_status']        = 'Status';
$_['entry_sort_order']    = 'Sort Order';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify Digipay!';
