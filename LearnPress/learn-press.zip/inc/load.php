<?php

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'LP_Addon_Digipay_Payment' ) ) {
	/**
	 * Class LP_Addon_Digipay_Payment
	 */
	class LP_Addon_Digipay_Payment extends LP_Addon {

		public $version             = LP_ADDON_DIGIPAY_PAYMENT_VER;
		public $require_version     = LP_ADDON_DIGIPAY_PAYMENT_REQUIRE_VER;

		public function __construct() {
			parent::__construct();
		}

		protected function _define_constants() {
			define( 'LP_ADDON_DIGIPAY_PAYMENT_PATH', dirname( LP_ADDON_DIGIPAY_PAYMENT_FILE ) );
			define( 'LP_ADDON_DIGIPAY_PAYMENT_INC', LP_ADDON_DIGIPAY_PAYMENT_PATH . '/inc/' );
			define( 'LP_ADDON_DIGIPAY_PAYMENT_URL', plugin_dir_url( LP_ADDON_DIGIPAY_PAYMENT_FILE ) );
			define( 'LP_ADDON_DIGIPAY_PAYMENT_TEMPLATE', LP_ADDON_DIGIPAY_PAYMENT_PATH . '/templates/' );
		}

		protected function _includes() {
			include_once LP_ADDON_DIGIPAY_PAYMENT_INC . 'class-lp-gateway-digipay.php';
		}

		protected function _init_hooks() {
			// add payment gateway class
			add_filter( 'learn_press_payment_method', array( $this, 'add_payment' ) );
			add_filter( 'learn-press/payment-methods', array( $this, 'add_payment' ) );
		}

		public function add_payment( $methods ) {
			$methods['digipay'] = 'LP_Gateway_Digipay';

			return $methods;
		}

		public function plugin_links() {
			$links[] = '<a href="' . admin_url( 'admin.php?page=learn-press-settings&tab=payments&section=digipay' ) . '">Settings</a>';

			return $links;
		}
	}
}
