<?php
/**
 * Template for displaying Digipay payment error message.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/addons/digipay-payment/payment-error.php.
 *
 * @author   Mohmmad Javad Heydari
 * @package  LearnPress/Digipay/Templates
 * @version  1.0.0
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit();
?>

<?php $settings = LP()->settings; ?>

<div class="learn-press-message error ">
	<div>Transation failed</div>
</div>
