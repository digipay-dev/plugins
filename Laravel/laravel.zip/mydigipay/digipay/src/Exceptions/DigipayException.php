<?php

namespace Kamva\Crud\Exceptions;

use Exception;

class DigipayException extends Exception{

}
