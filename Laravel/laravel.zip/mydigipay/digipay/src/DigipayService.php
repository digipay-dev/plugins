<?php

namespace MyDigipay\Digipay;

use MyDigipay\Digipay\Facade\Digipay;
use Illuminate\Http\Request;
use Kamva\Crud\Exceptions\DigipayException;

class DigipayService
{
    /**
     * @return DigipayGateway
     */
    public function init()
    {
        return new DigipayGateway();
    }

    /**
     * @param Request $request
     * @return array
     * @throws DigipayException
     */
    public function verify(Request $request)
    {
        return Digipay::init()->verify($request);
    }
}
