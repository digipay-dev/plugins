<?php

namespace MyDigipay\Digipay;

use Illuminate\Support\ServiceProvider;

class DigipayServiceProvider extends ServiceProvider
{

    public function register()
    {
        $this->app->singleton('digipay', function () {
            return new DigipayService();
        });

        $this->mergeConfigFrom(
            __DIR__ . '/config/digipay.php', 'digipay'
        );
    }

    public function boot()
    {
        $this->loadTranslationsFrom (__DIR__ . '/translations',   'digipay');

        $this->publishes([
            __DIR__ . '/config/digipay.php' => config_path('digipay.php'),
        ]);
    }
}
