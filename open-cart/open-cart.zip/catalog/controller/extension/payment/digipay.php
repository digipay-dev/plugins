<?php

include_once "DPGateway.php";

class ControllerExtensionPaymentDigipay extends Controller {

    private function initDP()
    {
        return new DPGateway([
            'type'              => $this->config->get('payment_digipay_type'),
            'username'          => $this->config->get('payment_digipay_username'),
            'password'          => $this->config->get('payment_digipay_password'),
            'client_id'         => $this->config->get('payment_digipay_client_id'),
            'client_secret'     => $this->config->get('payment_digipay_client_secret'),
            'access_token'      => $this->config->get('payment_digipay_access_token'),
            'refresh_token'     => $this->config->get('payment_digipay_refresh_token'),
        ], function ($accessToken, $refreshToken){
            $this->config->set('payment_digipay_access_token',  $accessToken);
            $this->config->set('payment_digipay_refresh_token', $refreshToken);
        });
    }

    public function index() {
        $this->load->language('extension/payment/digipay');

        $data1['text_connect']      = $this->language->get('text_connect');
        $data1['text_loading']      = $this->language->get('text_loading');
        $data1['text_wait']         = $this->language->get('text_wait');
        $data1['button_confirm']    = $this->language->get('button_confirm');

        return $this->load->view('extension/payment/digipay', $data1);
    }

    public function confirm() {

        $this->load->language('extension/payment/digipay');

        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        $amount                 = $this->getAmount($order_info);
        $data1['order_id']      = $this->session->data['order_id'];
        $data1['return']        = $this->url->link('checkout/success', '', true);
        $data1['cancel_return'] = $this->url->link('checkout/payment', '', true);
        $data1['back']          = $this->url->link('checkout/payment', '', true);
        $mobile                 = isset($order_info['fax']) ? $order_info['fax'] : $order_info['telephone'];
        $callback               = $this->url->link('extension/payment/digipay/callback', 'order_id=' . $data1['order_id'], true);

        $dp = $this->initDP();
        try {
            $url = $dp->createTicket($amount, $data1['order_id'], $callback, $mobile);

            $data1['action']    = $url;
            $json['success']    = $data1['action'];

        }catch (Exception $e){
            $json           = [];
            $json['error']  = $e->getMessage();
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function callback() {
        if ($this->session->data['payment_method']['code'] == 'digipay') {
            $this->load->language('extension/payment/digipay');
            $this->document->setTitle($this->language->get('text_title'));

            $data1['heading_title']     = 'Digipay';
            $data1['results']           = "";
            $data1['breadcrumbs']       = [
                [
                    'text' => $this->language->get('text_home'),
                    'href' => $this->url->link('common/home', '', true)
                ],
                [
                    'text' => $this->language->get('text_title'),
                    'href' => $this->url->link('extension/payment/digipay/callback', '', true)
                ]
            ];

            try {

                $result         = $_POST['result'];
                $amount         = $_POST['amount'];
                $providerId     = $_POST['providerId'];
                $trackingCode   = $_POST['trackingCode'];


                if($result != 'SUCCESS'){
                    throw new Exception($this->language->get('error_verify'));
                }

                if (isset($this->session->data['order_id'])) {
                    $order_id = $this->session->data['order_id'];
                } else {
                    $order_id = 0;
                }

                $this->load->model('checkout/order');

                $order_info = $this->model_checkout_order->getOrder($order_id);

                if (!$order_info){
                    throw new Exception($this->language->get('error_order_id'));
                }

                $dp = $this->initDP();
                $dp->verifyTicket($trackingCode);

                $comment = $this->language->get('text_results') . $trackingCode;
                $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_digipay_order_status_id'), $comment, true);

                $data1['error_warning']         = null;
                $data1['results']               = $trackingCode;
                $data1['button_continue']       = $this->language->get('button_complete');
                $data1['continue']              = $this->url->link('checkout/success');

            } catch (Exception $e) {
                $data1['error_warning']         = $e->getMessage();
                $data1['button_continue']       = $this->language->get('button_view_cart');
                $data1['continue']              = $this->url->link('checkout/cart');
            }

            $data1['column_left']       = $this->load->controller('common/column_left');
            $data1['column_right']      = $this->load->controller('common/column_right');
            $data1['content_top']       = $this->load->controller('common/content_top');
            $data1['content_bottom']    = $this->load->controller('common/content_bottom');
            $data1['footer']            = $this->load->controller('common/footer');
            $data1['header']            = $this->load->controller('common/header');

            $this->response->setOutput($this->load->view('extension/payment/digipay_confirm', $data1));
        }
    }

    private function getAmount($order_info) {
        $amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
        $amount = round($amount);
        $amount = $this->currency->convert($amount, $order_info['currency_code'], "TOM");
        return (int) $amount * 10;
    }
}
