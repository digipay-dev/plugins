<?php

if (!defined('ABSPATH')) {
    exit;
}

include_once "DPGateway.php";

class WCDigiPay extends WC_Payment_Gateway
{
    private $failedMassage;
    private $successMassage;

    public function __construct()
    {
        $this->id                   = 'WCDigiPay';
        $this->method_title         = __('درگاه هوشمند دیجی پی', 'woocommerce');
        $this->method_description   = __('تنظیمات درگاه پرداخت هوشمند دیجی پی برای ووکامرس', 'woocommerce');
        $this->icon                 = apply_filters('WCDigiPay_Logo', WP_PLUGIN_URL . '/' . plugin_basename(__DIR__) . '/logo.png');
        $this->has_fields           = false;

        $this->init_form_fields();
        $this->init_settings();

        $this->title            = __('درگاه هوشمند دیجی پی', 'woocommerce');
        $this->description      = $this->settings['description'];

        $this->successMassage   = $this->settings['success_massage'];
        $this->failedMassage    = $this->settings['failed_massage'];

        if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        } else {
            add_action('woocommerce_update_options_payment_gateways', array($this, 'process_admin_options'));
        }

        add_action('woocommerce_receipt_' . $this->id . '', array($this, 'digiPayPaymentRequest'));
        add_action('woocommerce_api_' . strtolower(get_class($this)) . '', array($this, 'digiPayPaymentCallback'));


    }

    public function process_admin_options()
    {
        if(isset($_POST['woocommerce_WCDigiPay_enabled'])){
            $this->init_settings();
            $this->settings['access_token']     = null;
            $this->settings['refresh_token']    = null;

            update_option(WC_Settings_API::get_option_key(), $this->settings, 'yes');
        }

        return parent::process_admin_options();
    }

    public function init_form_fields()
    {
        $this->form_fields = apply_filters('WCDigiPay_Config',
            [
                'enabled'               => [
                    'title'             => __('وضعیت درگاه', 'woocommerce'),
                    'type'              => 'checkbox',
                    'label'             => __('فعالسازی درگاه دیجی پی', 'woocommerce'),
                    'description'       => __('برای فعالسازی درگاه انتخاب کنید', 'woocommerce'),
                    'default'           => 'yes',
                    'desc_tip'          => true,
                ],
                'type'                  => [
                    'title'             => __('نوع درگاه پرداخت', 'woocommerce'),
                    'type'              => 'select',
                    'desc_tip'          => true,
                    'description'       => 'IPG - درگاه پرداخت هوشمند دیجی پی که با استفاده از الگوریتم های مختلف بهترین درگاه را در لحظه برای مشتری شما انتخاب می کند <Br><Br>WPG - درگاه پرداخت کیف پولی دیجی پی که امکان پرداخت از طریق کیف پول دیجی پی را برای مشتریان شما فراهم می کند <Br><Br>UPG - درگاه پرداخت جامع دیجی پی که ترکیبی از درگاه هوشمند و کیف پول را در خود دارد،  اگر کیف پول کسب و کاری شما راه اندازی شده پیشنهاد ما استفاده از این روش پرداخت است.',
                    'options'           => [
                        'IPG'     => 'درگاه پرداخت هوشمند (IPG)',
                        'UPG'     => 'درگاه پرداخت جامع (UPG)',
                        'WPG'     => 'درگاه کیف پولی (WPG)',
                    ],
                    'default'           => 'IPG'
                ],
                'description'           => [
                    'title'             => __('توضیحات پرداخت', 'woocommerce'),
                    'type'              => 'text',
                    'desc_tip'          => true,
                    'description'       => __('توضیحاتی که در طی عملیات پرداخت از طریق درگاه دیجی پی نمایش داده خواهد شد', 'woocommerce'),
                    'default'           => __('پرداخت هوشمند از طریق درگاه دیجی پی به وسیله کلیه کارت های عضو شبکه شتاب', 'woocommerce')
                ],
                'username'              => [
                    'title'             => __('نام کاربری', 'woocommerce'),
                    'type'              => 'text',
                    'description'       => __('نام کاربری دریافتی از دیجی پی', 'woocommerce'),
                    'default'           => '',
                    'desc_tip'          => true
                ],
                'password'              => [
                    'title'             => __('رمزعبور', 'woocommerce'),
                    'type'              => 'text',
                    'description'       => __('رمز عبور دریافتی از دیجی پی', 'woocommerce'),
                    'default'           => '',
                    'desc_tip'          => true
                ],
                'client_id'             => [
                    'title'             => __('Client ID', 'woocommerce'),
                    'type'              => 'text',
                    'description'       => __('Client ID دریافتی از دیجی پی', 'woocommerce'),
                    'default'           => '',
                    'desc_tip'          => true
                ],
                'client_secret'         => [
                    'title'             => __('Client Secret', 'woocommerce'),
                    'type'              => 'text',
                    'description'       => __('Client Secret دریافتی از دیجی پی', 'woocommerce'),
                    'default'           => '',
                    'desc_tip'          => true
                ],
                'success_massage'       => [
                    'title'             => __('پیام پرداخت موفق', 'woocommerce'),
                    'type'              => 'textarea',
                    'description'       => __('متن پیامی که میخواهید بعد از پرداخت موفق به کاربر نمایش دهید را وارد نمایید . همچنین می توانید از کد {ref_code} برای نمایش کد رهگیری دیجی پی استفاده نمایید .', 'woocommerce'),
                    'default'           => __('با تشکر از شما . سفارش شما با موفقیت پرداخت شد .', 'woocommerce'),
                ],
                'failed_massage'        => [
                    'title'             => __('پیام پرداخت ناموفق', 'woocommerce'),
                    'type'              => 'textarea',
                    'description'       => __('متن پیامی که میخواهید بعد از پرداخت ناموفق به کاربر نمایش دهید را وارد نمایید . همچنین می توانید از شورت کد {error} برای نمایش دلیل خطای رخ داده استفاده نمایید . این دلیل خطا از دیجی پی ارسال میگردد .', 'woocommerce'),
                    'default'           => __('پرداخت شما ناموفق بوده است . لطفا مجددا تلاش نمایید.', 'woocommerce'),
                ]
            ]
        );
    }

    public function process_payment($order_id)
    {
        $order = new WC_Order($order_id);
        return [
            'result'    => 'success',
            'redirect'  => $order->get_checkout_payment_url(true)
        ];
    }

    public function convertToIRR($amount, $currency)
    {
        switch ($currency){
            case 'IRHR' :
                return $amount * 1000;

            case 'IRHT' :
                return $amount * 10000;

            case 'IRR'  :
                return $amount;

            case 'IRT'  :
                return $amount * 10;

            default :
                throw new Exception("این ارز در دیجی پی پشتیبانی نمیشود");

        }
    }

    public function digiPayPaymentRequest($order_id)
    {
        global $woocommerce;

        echo '<form action="" method="POST" class="dp-checkout" id="dp-checkout"><input type="submit" name="dp_submit" class="button alt" id="dp-payment-button" value="' . __('پرداخت', 'woocommerce') . '"/><a class="button cancel" href="' . $woocommerce->cart->get_checkout_url() . '">' . __('بازگشت', 'woocommerce') . '</a></form><br/>';


        $woocommerce->session->dp_order_id = $order_id;

        $order          = new WC_Order($order_id);
        $currency       = $order->get_currency();

        try{
            $amount         = (int) $this->convertToIRR($order->order_total,$currency);

        }catch (Exception $e){
            wc_add_notice($e->getMessage(), 'error');
            exit;
        }

        $callbackUrl    = add_query_arg('wc_order', $order_id, WC()->api_request_url('WCDigiPay'));
        $mobile         = get_post_meta($order_id, '_billing_phone', true) ?: '-';
        $resID          = (int) $order->get_order_number();
        $dp             = $this->digipayInit();

        try{

            $result = $dp->createTicket($amount, $resID, $callbackUrl, $mobile);
            return wp_redirect($result);

        }catch (Exception $e){

            echo $e->getMessage();
            $message = ' تراکنش ناموفق بود - خطا : ' . $e->getMessage();

            $message = sprintf(__('خطا در هنگام ارسال به بانک : %s', 'woocommerce'), $message);

            $order->add_order_note($message);
            wc_add_notice($message, 'error');
        }

    }

    public function digiPayPaymentCallback()
    {
        global $woocommerce;

        if (isset($_GET['wc_order'])) {
            $order_id = $_GET['wc_order'];
        } else {
            $order_id = $woocommerce->session->dp_order_id;
            unset($woocommerce->session->dp_order_id);
        }

        if ($order_id) {

            $order = new WC_Order($order_id);

            $result         = $_POST['result'];
            $amount         = $_POST['amount'];
            $providerId     = $_POST['providerId'];
            $trackingCode   = $_POST['trackingCode'];


            if ($order->status !== 'completed') {

                if ($result === 'SUCCESS') {

                    $currency       = $order->get_currency();
                    $orderAmount    = (int) $this->convertToIRR($order->order_total,$currency);
                    $dp             = $this->digipayInit();

                    try {

                        if($amount != $orderAmount){
                            wc_add_notice("مبلغ پرداختی با سفارش مطابقت ندارد", 'error');
                            return wp_redirect($woocommerce->cart->get_checkout_url());
                        }

                        $dp->verifyTicket($trackingCode);
                        update_post_meta($order_id, '_transaction_id', $trackingCode);

                        $order->payment_complete($trackingCode);
                        $woocommerce->cart->empty_cart();

                        $order->add_order_note(sprintf(__('پرداخت موفقیت آمیز بود .<br/> کد رهگیری : %s', 'woocommerce'), $trackingCode), 1);

                        $msg = str_replace('{transaction_id}', $trackingCode, wpautop(wptexturize($this->successMassage)));

                        if ($msg) {
                            wc_add_notice($msg, 'success');
                        }

                        wp_redirect(add_query_arg('wc_status', 'success', $this->get_return_url($order)));

                    } catch (Exception $e) {


                        $msg = str_replace(array('{transaction_id}', '{fault}'), array($trackingCode, $e->getMessage()), wpautop(wptexturize($this->failedMassage)));

                        if ($msg) {
                            wc_add_notice($msg, 'error');
                        }

                        return wp_redirect($woocommerce->cart->get_checkout_url());

                    }
                }else{



                    $msg = str_replace(array('{transaction_id}', '{fault}'), array($trackingCode, "تراکنش ناموفق بود"), wpautop(wptexturize($this->failedMassage)));

                    if ($msg) {
                        wc_add_notice($msg, 'error');
                    }

                    return wp_redirect($woocommerce->cart->get_checkout_url());
                }

            }

            $msg = str_replace('{transaction_id}', get_post_meta($order_id, '_transaction_id', true), wpautop(wptexturize($this->successMassage)));

            if($msg) {
                wc_add_notice($msg, 'success');
            }

            return wp_redirect(add_query_arg('wc_status', 'success', $this->get_return_url($order)));
        }

        $msg = str_replace('{fault}', __('شماره سفارش وجود ندارد .', 'woocommerce'), wpautop(wptexturize($this->failedMassage)));

        if ($msg) {
            wc_add_notice($msg, 'error');
        }

        return wp_redirect($woocommerce->cart->get_checkout_url());
    }

    private function digipayInit()
    {
        $this->init_settings();

        $hook = function ($accessToken, $refreshToken){

            $this->settings['access_token']     = $accessToken;
            $this->settings['refresh_token']    = $refreshToken;

            update_option(WC_Settings_API::get_option_key(), $this->settings, 'yes');
            return true;
        };

        return new DPGateway($this->settings, $hook);
    }
}

