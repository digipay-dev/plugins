<?php
class ModelExtensionPaymentDigipay extends Model {

  	public function getMethod($address) {
		$this->load->language('extension/payment/digipay');

		if ($this->config->get('payment_digipay_status')) {
      		$status = true;
      	} else {
			$status = false;
		}

		$method_data = [];

		if ($status) {
      		$method_data = [
				'code'       => 'digipay',
				'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_digipay_sort_order')
			];
    	}

    	return $method_data;
  	}
}
?>
